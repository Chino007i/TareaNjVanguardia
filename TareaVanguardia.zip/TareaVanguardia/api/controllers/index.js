module.exports = {
  StudentController: require("./student.controller"),
  TeacherController: require("./teacher.controller"),
  CourseController: require("./course.controller")
};
