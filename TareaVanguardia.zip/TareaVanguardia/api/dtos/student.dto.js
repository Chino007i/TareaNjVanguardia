class StudentDto {
    id = 0;
    name = "";
    lastname = "";
    createdAt = null;
    updatedAt = null;
}

module.exports = StudentDto;