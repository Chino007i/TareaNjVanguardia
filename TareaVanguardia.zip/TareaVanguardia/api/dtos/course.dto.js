class CourseDto {
    id = 0;
    name = "";
}

module.exports = CourseDto;