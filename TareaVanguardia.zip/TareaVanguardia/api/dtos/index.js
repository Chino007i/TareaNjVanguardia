module.exports = {
    StudentDto: require("./student.dto"),
    TeacherDto: require("./teacher.dto"),
    CourseDto: require("./course.dto")
};