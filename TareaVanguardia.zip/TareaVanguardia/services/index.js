module.exports = {
  StudentService: require("./student.service"),
  TeacherService: require("./teacher.service"),
  CourseService: require("./course.service"),
  SubjectService: require("./subject.service"),
  RegistrationService: require("./registration.service"),
  SectionService: require("./section.service")
};
