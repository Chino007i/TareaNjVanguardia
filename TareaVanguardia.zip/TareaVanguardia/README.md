# Node.js RESTful API implementando Clean Architecture

Serie de videos en Youtube: <https://www.youtube.com/watch?v=gc-v3_LDjPk&list=PLzHaXzj_WAyn-kfjTcXJP3PMjS2I-QA0c>
