module.exports = {
    StudentRepository: require("./student.repository"),
    TeacherRepository: require("./teacher.repository"),
    CourseRepository: require("./course.repository"),
    SectionRepository: require("./section.repository"),
    CourseRepository: require("./course.repository"),
    RegistrationRepository: require("./registration.repository")
};