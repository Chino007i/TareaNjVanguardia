class Student {
  id = 0;
  name = null;
}

module.exports = Student;
