module.exports = {
  Student: require("./student"),
  Teacher: require("./student"),
  Course: require("./course")
};
