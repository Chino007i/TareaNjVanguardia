class Teacher {
  id = 0;
  name = null;
  lastname = null;
  createdAt = null;
  updatedAt = null;
}

module.exports = Teacher;
